function redirectToAlgorithms() {
  window.location.href = "main.html";
}

