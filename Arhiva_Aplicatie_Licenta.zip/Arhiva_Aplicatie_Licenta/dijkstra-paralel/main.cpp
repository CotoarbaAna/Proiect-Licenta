#include <iostream>
#include <ctime>
#include <cmath>
#include <omp.h>
#include <chrono>
#include <vector>
#include <fstream>

#define INT_MAX 100000
#define TRUE 1
#define FALSE 0

struct Edge {
    int u;
    int v;
};

struct Vertex {
    int title;
    bool visited;
};

void printArray(int* array, int V) {
    for (int i = 0; i < V; i++) {
        std::cout << "Path to Vertex " << i << " is " << array[i] << std::endl;
    }
}

int findEdge(Vertex u, Vertex v, Edge* edges, int* weights,int E) {
    for (int i = 0; i < E; i++) {
        if (edges[i].u == u.title && edges[i].v == v.title) {
            return weights[i];
        }
    }
    return INT_MAX;
}

int minimum(int A, int B) {
    if (A > B) {
        return B;
    } else {
        return A;
    }
}

int minWeight(int* len, Vertex* vertices, int V) {
    int minimum = INT_MAX;
    for (int i = 0; i < V; i++) {
        if (vertices[i].visited == TRUE) {
            continue;
        } else if (vertices[i].visited == FALSE && len[i] < minimum) {
            minimum = len[i];
        }
    }
    return minimum;
}

int minPath(Vertex* vertices, int* len, int V) {
    int i;
    int min = minWeight(len, vertices,V);

    for (i = 0; i < V; i++) {
        if (vertices[i].visited == FALSE && len[vertices[i].title] == min) {
            vertices[i].visited = TRUE;
            return i;
        }
    }
}

void DijkstraOMP(Vertex* vertices, Edge* edges, int* weights, Vertex* root, int V,int E) {
    double start, end;
    root->visited = TRUE;
    int len[V];
    len[(int)root->title] = 0;

    int i, j;

    for (i = 0; i < V; i++) {
        if (vertices[i].title != root->title) {
            len[(int)vertices[i].title] = findEdge(*root, vertices[i], edges, weights, E);
        } else {
            vertices[i].visited = TRUE;
        }
    }

    for (j = 0; j < V; j++) {
        Vertex u;
        int h = minPath(vertices, len, V);
        u = vertices[h];

#pragma omp parallel for schedule(runtime) private(i)
        for (i = 0; i < V; i++) {
            if (vertices[i].visited == FALSE) {
                int c = findEdge(u, vertices[i], edges, weights, E);
                len[vertices[i].title] = minimum(len[vertices[i].title], len[u.title] + c);
            }
        }
    }
    //printArray(len, V);
}

int main(int argc, char const *argv[]) {
    std::ifstream inputFile(argv[1]);
    if (!inputFile.is_open()) {
        std::cout << "Failed to open the input file." << std::endl;
        return 1;
    }

    int V, E;
    inputFile >> V >> E;
    std::vector<Vertex> vertices(V);
    std::vector<Edge> edges(E);
    std::vector<int> weights(E);

    for (int i = 0; i < V; i++) {
        Vertex a;
        a.title = i;
        a.visited = FALSE;
        vertices[i] = a;
    }

    for (int i = 0; i < E; i++) {
        inputFile >> edges[i].u >> edges[i].v;
        inputFile >> weights[i];
    }

    Vertex root;
    inputFile >> root.title;
    root.visited = FALSE;

    inputFile.close();

    auto startTime = std::chrono::steady_clock::now();
    DijkstraOMP(vertices.data(), edges.data(), weights.data(), &root, V,E);
    auto endTime = std::chrono::steady_clock::now();
    auto elapsedTime = std::chrono::duration_cast<std::chrono::milliseconds>(endTime - startTime).count();

    std::cout << "Dijkstra parallel: " << elapsedTime << " milliseconds" << std::endl;
    return 0;
}