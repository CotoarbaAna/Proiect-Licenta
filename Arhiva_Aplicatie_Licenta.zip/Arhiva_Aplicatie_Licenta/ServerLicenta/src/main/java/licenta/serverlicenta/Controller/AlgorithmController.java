package licenta.serverlicenta.Controller;

import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;

@RestController
public class AlgorithmController {

    String path = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/AlgorithmsExes/";


    @PostMapping("/dijkstra-s")
    public String executeDijkstraSecv(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "Error: Empty file";
        }
        try {
            int min = 1;
            int max = 5000000;
            int random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
            String filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                    + File.separator + random_int + file.getOriginalFilename();
            while(new File(filePath).exists())
            {
                random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
                filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                        + File.separator + random_int + file.getOriginalFilename();
            }
            file.transferTo(new File(filePath));
            String command = path + "dijkstra_secvential.exe" + " " + filePath;
            Process process = Runtime.getRuntime().exec(command);
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }
            int exitCode = process.waitFor();
            if (exitCode == 0) {
                new File(filePath).delete();
                return output.toString();
            } else {
                return "Error occurred during algorithm execution";
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return "Error occurred during algorithm execution: " + e.getMessage();
        }
    }

    @PostMapping("/bellmanford-s")
    public String executeBellmanFordSecv(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "Error: Empty file";
        }

        try {
            int min = 1;
            int max = 5000000;
            int random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
            //Save the uploaded file to a specific location
            String filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                    + File.separator + random_int + file.getOriginalFilename(); // Update the file path as needed
            while(new File(filePath).exists())
            {
                random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
                filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                        + File.separator + random_int + file.getOriginalFilename();
            }
            file.transferTo(new File(filePath));

            // Call the algorithm executable with the full path of the saved file
            String command = path + "bellmanford_secvential.exe" + " " + filePath; // Construct the command to execute the algorithm
            Process process = Runtime.getRuntime().exec(command);

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Wait for the process to complete
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                new File(filePath).delete();
                return output.toString(); // Return the algorithm result
            } else {
                return "Error occurred during algorithm execution";
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return "Error occurred during algorithm execution: " + e.getMessage();
        }
    }

    @PostMapping("/bfs-s")
    public String executeBFSSecv(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "Error: Empty file";
        }
        try {
            int min = 1;
            int max = 5000000;
            int random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
            //Save the uploaded file to a specific location
            String filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                    + File.separator + random_int + file.getOriginalFilename(); // Update the file path as needed
            while(new File(filePath).exists())
            {
                random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
                filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                        + File.separator + random_int + file.getOriginalFilename();
            }
            file.transferTo(new File(filePath));

            // Call the algorithm executable with the full path of the saved file
            String command = path + "bfs_secvential.exe" + " " + filePath; // Construct the command to execute the algorithm
            Process process = Runtime.getRuntime().exec(command);

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Wait for the process to complete
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                new File(filePath).delete();
                return output.toString(); // Return the algorithm result
            } else {
                return "Error occurred during algorithm execution";
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return "Error occurred during algorithm execution: " + e.getMessage();
        }
    }

    @PostMapping("/dijkstra-p")
    public String executeDijkstraParalel(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "Error: Empty file";
        }
        try {
            int min = 1;
            int max = 5000000;
            int random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
            //Save the uploaded file to a specific location
            String filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                    + File.separator + random_int + file.getOriginalFilename(); // Update the file path as needed
            while(new File(filePath).exists())
            {
                random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
                filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                        + File.separator + random_int + file.getOriginalFilename();
            }
            file.transferTo(new File(filePath));

            // Call the algorithm executable with the full path of the saved file
            String command = path + "dijkstra_paralel.exe" + " " + filePath; // Construct the command to execute the algorithm
            Process process = Runtime.getRuntime().exec(command);

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Wait for the process to complete
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                new File(filePath).delete();
                return output.toString(); // Return the algorithm result
            } else {
                return "Error occurred during algorithm execution";
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return "Error occurred during algorithm execution: " + e.getMessage();
        }
    }

    @PostMapping("/bellmanford-p")
    public String executeBellmanFordParalel(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "Error: Empty file";
        }
        try {
            int min = 1;
            int max = 5000000;
            int random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
            //Save the uploaded file to a specific location
            String filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                    + File.separator + random_int + file.getOriginalFilename(); // Update the file path as needed
            while(new File(filePath).exists())
            {
                random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
                filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                        + File.separator + random_int + file.getOriginalFilename();
            }
            file.transferTo(new File(filePath));

            // Call the algorithm executable with the full path of the saved file
            String command = path + "bellmanford_paralel.exe" + " " + filePath; // Construct the command to execute the algorithm
            Process process = Runtime.getRuntime().exec(command);

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Wait for the process to complete
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                new File(filePath).delete();
                return output.toString(); // Return the algorithm result
            } else {
                return "Error occurred during algorithm execution";
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return "Error occurred during algorithm execution: " + e.getMessage();
        }
    }

    @PostMapping("/bfs-p")
    public String executeBFSParalel(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return "Error: Empty file";
        }
        try {
            int min = 1;
            int max = 5000000;
            int random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
            //Save the uploaded file to a specific location
            String filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                    + File.separator + random_int + file.getOriginalFilename(); // Update the file path as needed
            while(new File(filePath).exists())
            {
                random_int = (int)Math.floor(Math.random() * (max - min + 1) + min);
                filePath = "C:/Users/user/Desktop/ServerLicenta/src/main/java/licenta/serverlicenta/Data"
                        + File.separator + random_int + file.getOriginalFilename();
            }
            file.transferTo(new File(filePath));

            // Call the algorithm executable with the full path of the saved file
            String command = path + "bfs_paralel.exe" + " " + filePath; // Construct the command to execute the algorithm
            Process process = Runtime.getRuntime().exec(command);

            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder output = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                output.append(line).append("\n");
            }

            // Wait for the process to complete
            int exitCode = process.waitFor();

            if (exitCode == 0) {
                new File(filePath).delete();
                return output.toString(); // Return the algorithm result
            } else {
                return "Error occurred during algorithm execution";
            }

        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
            return "Error occurred during algorithm execution: " + e.getMessage();
        }
    }
}
