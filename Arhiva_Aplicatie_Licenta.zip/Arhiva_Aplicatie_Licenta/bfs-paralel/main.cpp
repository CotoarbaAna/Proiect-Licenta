#include <stdlib.h>
#include <vector>
#include <queue>
#include <omp.h>
#include <iostream>
#include <fstream>
#include <chrono>

using namespace std;

vector<vector<int>> graph;
queue<int> qq;
int* marked = NULL;
unsigned int i, threads_num;
int nodesNum, node1, node2, node, root;

void s_init(string filename)
{
    ifstream fin(filename);

    fin >> nodesNum;

    graph.resize(nodesNum + 1);
    marked = new int[nodesNum + 1]();

    while (fin >> node1 >> node2)
    {
        graph[node1].push_back(node2);
        graph[node2].push_back(node1);
    }

    fin.close();
}

// Display the graph
void display()
{
    for (unsigned int i = 0; i < graph.size(); ++i)
    {
        if (graph[i].size() != 0)
        {
            cout << i << "->";
            for (unsigned int j = 0; j < graph[i].size(); ++j)
            {
                cout << graph[i][j] << " ";
            }
            cout << "\n";
        }
    }
}

// Parallel Implementation of BFS
void p_bfs()
{
    // Setup number of threads
    omp_set_num_threads(threads_num);

    // Setup omp lock
    omp_lock_t lck;
    omp_init_lock(&lck);

    root = 0;
    qq.push(root);
    while (!qq.empty())
    {
#pragma omp parallel
        {
#pragma omp single
            {
                node = qq.front();
                qq.pop();

                marked[node] = 2;
            }

#pragma omp barrier

#pragma omp parallel for shared(lck) schedule(dynamic)
            for (i = 0; i < graph[node].size(); ++i)
            {
                omp_set_lock(&lck);
                if (marked[graph[node][i]] == 0)
                {
                    qq.push(graph[node][i]);
                    marked[graph[node][i]] = 1;
                }
                omp_unset_lock(&lck);
            }
        }
    }

    // Cleanup
    omp_destroy_lock(&lck);
    free(marked);
}

int main(int argc, char const* argv[])
{
    threads_num = 4;
    if (argc <= 1) {
        cout<<"INPUT FILE WAS NOT FOUND!";
    }
    string filename = argv[1];

    s_init(filename);

    auto start = chrono::steady_clock::now();
    p_bfs();
    auto end = chrono::steady_clock::now();
    auto dur = chrono::duration_cast<chrono::milliseconds>(end - start).count();
    cout << "Parallel BFS: " << dur << "ms" << endl;

    return 0;
}
