package licenta.serverlicenta;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerLicentaApplicationTests {

    @Test
    void contextLoads() {
    }

}
