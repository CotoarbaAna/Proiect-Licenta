let dropdownItems = document.querySelectorAll(".menu .dropdown li");
let fileUploadContainer = document.getElementById("fileUploadContainer");
let testButtonSeq = document.getElementById("testButtonSeq")
let testButtonPar = document.getElementById("testButtonPar")
let fileInput = document.getElementById("fileInput");
let textBoxContainerBFS = document.getElementById("text-box-container-bfs");
let textBoxContainerDijkstra = document.getElementById("text-box-container-dijkstra");
let textBoxContainerBellman = document.getElementById("text-box-container-bellman");
let textChooseAlg = document.getElementById("text-choose");
let btnChoosePerfType = document.getElementById("btn-choose");
let arrow1 = document.getElementById("pointingArrow1");
let arrow2 = document.getElementById("pointingArrow2");
let arrowMain = document.getElementById("pointingArrow-main");
let timeDijDivSeq = document.getElementById("dij-time-seq");
let timeDijDivPar = document.getElementById("dij-time-par");
let timeBFSDivSeq = document.getElementById("bfs-time-seq");
let timeBFSDivPar = document.getElementById("bfs-time-par");
let timeBFordDivSeq = document.getElementById("bford-time-seq");
let timeBFordDivPar = document.getElementById("bford-time-par");
let chosenAlg;

textBoxContainerDijkstra.style.display = "none";
textBoxContainerBellman.style.display = "none";
textBoxContainerBFS.style.display = "none";
arrow1.style.display = "none";
arrow2.style.display = "none";
arrowMain.style.display = "block";
textChooseAlg.style.display = "block";
btnChoosePerfType.style.display = "none";
testButtonSeq.style.display = "none";
testButtonPar.style.display = "none";
timeDijDivSeq.style.display = "none";
timeDijDivPar.style.display = "none";
timeBFSDivSeq.style.display = "none";
timeBFSDivPar.style.display = "none";
timeBFordDivSeq.style.display = "none";
timeBFordDivPar.style.display = "none";

for (let i = 0; i < dropdownItems.length; i++) {
  dropdownItems[i].addEventListener("click", function () {
    let selectedItem = this.textContent.trim();
    chosenAlg = selectedItem;
    fileUploadContainer.style.display = "none";
    fileInput.value = '';
    if (selectedItem === "Dijkstra" || selectedItem === "BFS" || selectedItem === "Bellman Ford") {
      fileUploadContainer.style.display = "block";
      testButtonSeq.style.display = "block";
      testButtonPar.style.display = "block";
      arrow1.style.display = "block";
      arrow2.style.display = "block";
      testButtonSeq.style.display = "block";
      testButtonPar.style.display = "block";
      arrowMain.style.display = "none";
      textChooseAlg.style.display = "none";
      btnChoosePerfType.style.display = "block";
      timeBFSDivSeq.style.display = "none";
      timeBFSDivSeq.innerHTML = '';
      timeBFSDivPar.style.display = "none";
      timeBFSDivPar.innerHTML = '';
      timeDijDivSeq.style.display = "none";
      timeDijDivSeq.innerHTML = '';
      timeDijDivPar.style.display = "none";
      timeDijDivPar.innerHTML = '';
      timeBFordDivSeq.style.display = "none";
      timeBFordDivSeq.innerHTML = '';
      timeBFordDivPar.style.display = "none";
      timeBFordDivPar.innerHTML = '';

      if (selectedItem === "Dijkstra") {
        textBoxContainerBFS.style.display = "none";
        textBoxContainerBellman.style.display = "none";
        textBoxContainerDijkstra.style.display = "block";
      }

      if (selectedItem === "BFS") {
        textBoxContainerBellman.style.display = "none";
        textBoxContainerDijkstra.style.display = "none";
        textBoxContainerBFS.style.display = "block";
      }

      if (selectedItem === "Bellman Ford") {
        textBoxContainerBFS.style.display = "none";
        textBoxContainerDijkstra.style.display = "none";
        textBoxContainerBellman.style.display = "block";
      }

    }

  });
}

testButtonSeq.addEventListener("click", function () {
  if (fileInput.files.length === 0) {
    showDialog('Încărcați un fișier', 3500);
  } else {
    function extractExecutionTime(result) {
      const regex = /(\d+)\s*(?:milliseconds|ms)/;
      const match = result.match(regex);
      if (match && match[1]) {
        console.log("Obtained " + parseInt(match[1]));
        return parseInt(match[1]);
      }
      return 0;
    }
    if (chosenAlg === "Dijkstra") {
      if(timeDijDivPar.style.display === 'block' && timeDijDivSeq.style.display === 'block')
      {
        timeDijDivPar.style.display = 'none';
      }
        timeBFSDivSeq.style.display = 'none';
      timeBFordDivSeq.style.display = 'none';
      timeDijDivSeq.style.display = 'block';
      let file = fileInput.files[0];
      let formData = new FormData();
      formData.append('file', file);
      let timeContainer = document.getElementById("dij-time-seq")
      timeContainer.innerHTML = '';
      let executionDescr = document.createElement('p');
      executionDescr.innerText = 'Se vor realiza 10 executii';
      timeContainer.appendChild(executionDescr);
      let numberOfExecutions = 10; // Number of times to execute the algorithm
      let delayBetweenExecutions = 1000; // Delay in milliseconds
      function executeNextAlgorithm(executionIndex, totalTime = 0, executionTimes = []) {
        fetch('http://localhost:8080/dijkstra-s', {
          method: 'POST',
          body: formData
        })
          .then(response => response.text())
          .then(result => {
            let executionResult = document.createElement('p');
            executionResult.innerText = 'Exec ' + (executionIndex + 1) + ': ' + result;
            timeContainer.appendChild(executionResult);
            const executionTime = extractExecutionTime(result);
            executionTimes.push(executionTime);
            totalTime += executionTime;
            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1,  totalTime, executionTimes), delayBetweenExecutions);
            }
            else {
              const meanTime = totalTime / numberOfExecutions;
              const meanTimeFormatted = meanTime.toFixed(2);
              let meanResult = document.createElement('p');
              meanResult.innerText = 'Media aritmetica a timpilor executiilor este ' + meanTimeFormatted + 'ms.';
              timeContainer.appendChild(meanResult);
            }
          })
          .catch(error => {
            console.error('Error occurred during algorithm execution:', error);
            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1, totalTime, executionTimes), delayBetweenExecutions);
            }
          });
      }
      executeNextAlgorithm(0);
      let executionObs = document.createElement('p');
      executionObs.innerText = 'Observatie : Modul de lucru paralel este mai eficient cu cat dimensiunea ' +
        'grafului creste.';
      timeContainer.appendChild(executionObs);

    }
    else if (chosenAlg === "BFS") {
      if(timeBFSDivPar.style.display === 'block' && timeBFSDivSeq.style.display === 'block')
        timeBFSDivPar.style.display = 'none';
      timeBFordDivSeq.style.display = 'none';
      timeDijDivSeq.style.display = 'none';
      timeBFSDivSeq.style.display = 'block';
      timeBFSDivSeq.innerHTML = '';
      timeBFSDivSeq.innerText = '';
      let file = fileInput.files[0];

      let formData = new FormData();
      formData.append('file', file);

      let timeContainer = document.getElementById("bfs-time-seq");
      timeContainer.innerHTML = '';
      timeContainer.innerText = '';

      let executionDescr = document.createElement('p');
      executionDescr.innerText = 'Se vor realiza 10 executii';

      timeContainer.appendChild(executionDescr);

      let numberOfExecutions = 10; // Number of times to execute the algorithm
      let delayBetweenExecutions = 1000; // Delay in milliseconds

      function executeNextAlgorithm(executionIndex, totalTime = 0, executionTimes = []) {
        fetch('http://localhost:8080/bfs-s', {
          method: 'POST',
          body: formData
        })
          .then(response => response.text())
          .then(result => {
            let executionResult = document.createElement('p');
            executionResult.innerText = 'Exec ' + (executionIndex + 1) + ': ' + result.replace(/\n/g, ""); // Display the execution number and result
            timeContainer.appendChild(executionResult); // Add the result to the result container

            const executionTime = extractExecutionTime(result); // Assuming result is a number in milliseconds
            executionTimes.push(executionTime); // Add the execution time to the array
            totalTime += executionTime;

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1,  totalTime, executionTimes), delayBetweenExecutions);
            }
            else {
              // Calculate arithmetic mean
              const meanTime = totalTime / numberOfExecutions;
              const meanTimeFormatted = meanTime.toFixed(2);
              let meanResult = document.createElement('p');
              meanResult.innerText = 'Media aritmetica a timpilor executiilor este ' + meanTimeFormatted + 'ms.';
              timeContainer.appendChild(meanResult); // Add the arithmetic mean to the result container
            }

          })
          .catch(error => {
            console.error('Error occurred during algorithm execution:', error);

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1), delayBetweenExecutions);
            }

          });
      }

      executeNextAlgorithm(0);

      let executionObs = document.createElement('p');
      executionObs.innerText = 'Observatie : Modul de lucru paralel este mai eficient cu cat dimensiunea ' +
        'grafului creste.';

      timeContainer.appendChild(executionObs);

    }
    else if (chosenAlg === "Bellman Ford") {
      if(timeBFordDivPar.style.display === 'block' && timeBFordDivSeq.style.display === 'block')
        timeBFordDivPar.style.display = 'none';
      timeBFSDivSeq.style.display = 'none';
      timeDijDivSeq.style.display = 'none';
      timeBFordDivSeq.style.display = 'block';
      let file = fileInput.files[0];

      let formData = new FormData();
      formData.append('file', file);

      let timeContainer = document.getElementById("bford-time-seq")
      timeContainer.innerHTML = '';

      let executionDescr = document.createElement('p');
      executionDescr.innerText = 'Se vor realiza 10 executii';

      timeContainer.appendChild(executionDescr);

      let numberOfExecutions = 10; // Number of times to execute the algorithm
      let delayBetweenExecutions = 1500; // Delay in milliseconds

      function executeNextAlgorithm(executionIndex, totalTime = 0, executionTimes = []) {
        fetch('http://localhost:8080/bellmanford-s', {
          method: 'POST',
          body: formData
        })
          .then(response => response.text())
          .then(result => {
            let executionResult = document.createElement('p');
            executionResult.innerText = 'Exec ' + (executionIndex + 1) + ': ' + result; // Display the execution number and result
            timeContainer.appendChild(executionResult); // Add the result to the result container

            const executionTime = extractExecutionTime(result); // Assuming result is a number in milliseconds
            executionTimes.push(executionTime); // Add the execution time to the array
            totalTime += executionTime;

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1,  totalTime, executionTimes), delayBetweenExecutions);
            }
            else {
              // Calculate arithmetic mean
              const meanTime = totalTime / numberOfExecutions;
              const meanTimeFormatted = meanTime.toFixed(2);
              let meanResult = document.createElement('p');
              meanResult.innerText = 'Media aritmetica a timpilor executiilor este ' + meanTimeFormatted + 'ms.';
              timeContainer.appendChild(meanResult); // Add the arithmetic mean to the result container
            }

          })
          .catch(error => {
            console.error('Error occurred during algorithm execution:', error);

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1), delayBetweenExecutions);
            }

          });
      }

      executeNextAlgorithm(0);

      let executionObs = document.createElement('p');
      executionObs.innerText = 'Observatie : Modul de lucru paralel este mai eficient cu cat dimensiunea ' +
        'grafului creste.';

      timeContainer.appendChild(executionObs);

    }
  }
})

testButtonPar.addEventListener("click", function () {
  if (fileInput.files.length === 0) {
    showDialog('Încărcați un fișier', 3500);
  } else {

    function extractExecutionTime(result) {
      const regex = /(\d+)\s*(?:milliseconds|ms)/;
      const match = result.match(regex);
      if (match && match[1]) {
        console.log("Obtained " + parseInt(match[1]));
        return parseInt(match[1]);
      }
      return 0; // Return 0 if the extraction fails or no match is found
    }

    if (chosenAlg === "Dijkstra") {
      if(timeDijDivSeq.style.display === 'block' && timeDijDivPar.style.display === 'block')
        timeDijDivSeq.style.display = 'none';
      timeBFSDivPar.style.display = 'none';
      timeBFordDivPar.style.display = 'none';
      timeDijDivPar.style.display = 'block';
      let file = fileInput.files[0];

      let formData = new FormData();
      formData.append('file', file);

      let timeContainer = document.getElementById("dij-time-par")
      timeContainer.innerHTML = '';

      let executionDescr = document.createElement('p');
      executionDescr.innerText = 'Se vor realiza 10 executii';

      timeContainer.appendChild(executionDescr);

      let numberOfExecutions = 10; // Number of times to execute the algorithm
      let delayBetweenExecutions = 1000; // Delay in milliseconds

      function executeNextAlgorithm(executionIndex, totalTime = 0, executionTimes = []) {
        fetch('http://localhost:8080/dijkstra-p', {
          method: 'POST',
          body: formData
        })
          .then(response => response.text())
          .then(result => {
            let executionResult = document.createElement('p');
            executionResult.innerText = 'Exec ' + (executionIndex + 1) + ': ' + result; // Display the execution number and result
            timeContainer.appendChild(executionResult); // Add the result to the result container

            const executionTime = extractExecutionTime(result); // Assuming result is a number in milliseconds
            executionTimes.push(executionTime); // Add the execution time to the array
            totalTime += executionTime;

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1,  totalTime, executionTimes), delayBetweenExecutions);
            }
            else {
              // Calculate arithmetic mean
              const meanTime = totalTime / numberOfExecutions;
              const meanTimeFormatted = meanTime.toFixed(2);
              let meanResult = document.createElement('p');
              meanResult.innerText = 'Media aritmetica a timpilor executiilor este ' + meanTimeFormatted + 'ms.';
              timeContainer.appendChild(meanResult); // Add the arithmetic mean to the result container
            }

          })
          .catch(error => {
            console.error('Error occurred during algorithm execution:', error);

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1), delayBetweenExecutions);
            }

          });
      }

      executeNextAlgorithm(0);

      let executionObs = document.createElement('p');
      executionObs.innerText = 'Observatie : Modul de lucru paralel este mai eficient cu cat dimensiunea ' +
        'grafului creste.';

      timeContainer.appendChild(executionObs);

    }
    else if (chosenAlg === "BFS") {
      if(timeBFSDivSeq.style.display === 'block' && timeBFSDivPar.style.display === 'block')
        timeBFSDivSeq.style.display = 'none';
      timeDijDivPar.style.display = 'none';
      timeBFordDivPar.style.display = 'none';
      timeBFSDivPar.style.display = 'block';
      let file = fileInput.files[0];

      let formData = new FormData();
      formData.append('file', file);

      let timeContainer = document.getElementById("bfs-time-par")
      timeContainer.innerHTML = '';

      let executionDescr = document.createElement('p');
      executionDescr.innerText = 'Se vor realiza 10 executii';

      timeContainer.appendChild(executionDescr);

      let numberOfExecutions = 10; // Number of times to execute the algorithm
      let delayBetweenExecutions = 1000; // Delay in milliseconds

      function executeNextAlgorithm(executionIndex, totalTime = 0, executionTimes = []) {
        fetch('http://localhost:8080/bfs-p', {
          method: 'POST',
          body: formData
        })
          .then(response => response.text())
          .then(result => {
            let executionResult = document.createElement('p');
            executionResult.innerText = 'Exec ' + (executionIndex + 1) + ': ' + result; // Display the execution number and result
            timeContainer.appendChild(executionResult); // Add the result to the result container

            const executionTime = extractExecutionTime(result); // Assuming result is a number in milliseconds
            executionTimes.push(executionTime); // Add the execution time to the array
            totalTime += executionTime;

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1,  totalTime, executionTimes), delayBetweenExecutions);
            }
            else {
              // Calculate arithmetic mean
              const meanTime = totalTime / numberOfExecutions;
              const meanTimeFormatted = meanTime.toFixed(2);
              let meanResult = document.createElement('p');
              meanResult.innerText = 'Media aritmetica a timpilor executiilor este ' + meanTimeFormatted + 'ms.';
              timeContainer.appendChild(meanResult); // Add the arithmetic mean to the result container
            }

          })
          .catch(error => {
            console.error('Error occurred during algorithm execution:', error);

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1), delayBetweenExecutions);
            }

          });
      }

      executeNextAlgorithm(0);

      let executionObs = document.createElement('p');
      executionObs.innerText = 'Observatie : Modul de lucru paralel este mai eficient cu cat dimensiunea ' +
        'grafului creste.';

      timeContainer.appendChild(executionObs);

    }
    else if (chosenAlg === "Bellman Ford") {
      if(timeBFordDivSeq.style.display === 'block' && timeBFordDivPar.style.display === 'block')
        timeBFordDivSeq.style.display = 'none';
      timeBFSDivPar.style.display = 'none';
      timeDijDivPar.style.display = 'none';
      timeBFordDivPar.style.display = 'block';
      let file = fileInput.files[0];

      let formData = new FormData();
      formData.append('file', file);

      let timeContainer = document.getElementById("bford-time-par")
      timeContainer.innerHTML = '';

      let executionDescr = document.createElement('p');
      executionDescr.innerText = 'Se vor realiza 10 executii';

      timeContainer.appendChild(executionDescr);

      let numberOfExecutions = 10; // Number of times to execute the algorithm
      let delayBetweenExecutions = 1500; // Delay in milliseconds

      function executeNextAlgorithm(executionIndex, totalTime = 0, executionTimes = []) {
        fetch('http://localhost:8080/bellmanford-p', {
          method: 'POST',
          body: formData
        })
          .then(response => response.text())
          .then(result => {
            let executionResult = document.createElement('p');
            executionResult.innerText = 'Exec ' + (executionIndex + 1) + ': ' + result; // Display the execution number and result
            timeContainer.appendChild(executionResult); // Add the result to the result container

            const executionTime = extractExecutionTime(result); // Assuming result is a number in milliseconds
            executionTimes.push(executionTime); // Add the execution time to the array
            totalTime += executionTime;

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1,  totalTime, executionTimes), delayBetweenExecutions);
            }
            else {
              // Calculate arithmetic mean
              const meanTime = totalTime / numberOfExecutions;
              const meanTimeFormatted = meanTime.toFixed(2);
              let meanResult = document.createElement('p');
              meanResult.innerText = 'Media aritmetica a timpilor executiilor este ' + meanTimeFormatted + 'ms.';
              timeContainer.appendChild(meanResult); // Add the arithmetic mean to the result container
            }

          })
          .catch(error => {
            console.error('Error occurred during algorithm execution:', error);

            if (executionIndex < numberOfExecutions - 1) {
              setTimeout(() => executeNextAlgorithm(executionIndex + 1), delayBetweenExecutions);
            }


          });
      }

      executeNextAlgorithm(0);

      let executionObs = document.createElement('p');
      executionObs.innerText = 'Observatie : Modul de lucru paralel este mai eficient cu cat dimensiunea ' +
        'grafului creste.';

      timeContainer.appendChild(executionObs);

    }
  }
})

function showDialog(message, duration) {
  let customDialog = document.createElement('div');
  customDialog.id = 'customDialog';

  let title = document.createElement('h2');
  title.innerText = 'Niciun fișier selectat';

  let content = document.createElement('p');
  content.innerText = message;

  customDialog.appendChild(title);
  customDialog.appendChild(content);
  document.body.appendChild(customDialog);

  setTimeout(function () {
    customDialog.parentNode.removeChild(customDialog);
  }, duration);
}

function addWeightsToEdges(contents) {
    var lines = contents.split("\n");
    var firstLine = lines[0].trim();
    var numEdges = lines.length - 1;

    // Update the first line with the number of nodes and number of edges
    var updatedFirstLine = firstLine + " " + numEdges;
    lines[0] = updatedFirstLine;

    // Join the lines back into a single string
    var updatedContents = lines.join("\n");

    return updatedContents;
}

// function cytobfs(graph, startNode) {
//   const visited = new Set();
//   const queue = [];
//   const traversal = [];
//
//   queue.push(startNode);
//   visited.add(startNode);
//
//   while (queue.length > 0) {
//     const currentNode = queue.shift();
//     traversal.push(currentNode);
//     const neighbors = graph.elements(`#${currentNode}`).outgoers().nodes();
//     neighbors.forEach(neighbor => {
//       const neighborId = neighbor.id();
//       if (!visited.has(neighborId)) {
//         queue.push(neighborId);
//         visited.add(neighborId);
//       }
//     });
//   }
//   return traversal;
// }

class PriorityQueue {
  constructor() {
    this.elements = [];
  }

  enqueue(element, priority) {
    const item = { element, priority };
    let added = false;

    for (let i = 0; i < this.elements.length; i++) {
      if (item.priority < this.elements[i].priority) {
        this.elements.splice(i, 0, item);
        added = true;
        break;
      }
    }

    if (!added) {
      this.elements.push(item);
    }
  }

  dequeue() {
    if (this.isEmpty()) {
      return null;
    }

    return this.elements.shift();
  }

  isEmpty() {
    return this.elements.length === 0;
  }
}

document.addEventListener("DOMContentLoaded", function () {

    document.getElementById("fileInput").addEventListener("change", function (event) {
      if(chosenAlg === "BFS") {
        var cy = cytoscape({
          container: document.getElementById("cy"),

          style: [
            {
              selector: 'node',
              style: {
                "background-color": "blue",
                label: "data(id)",
                "border-width": 2,
                "border-color": "black",
                width: 15,
                height: 15
              }
            },
            {
              selector: 'edge[visited]',
              style: {
                'line-color': 'red'
              }
            },
            {
              selector: 'node[id = "0"]',
              style: {
                'background-color': 'red',
                label: 'data(id)',
                'border-width': 2,
                'border-color': 'black',
                width: 20,
                height: 20
              }
            },
            {
              selector: 'edge',
              style: {
                width: 3,
                'line-color': 'gray',
                label: "data(weight)"
              }
            },
            {
              selector: "edge[!weight]",
              style: {
                width: 3,
                'line-color': 'gray',
                label: ""
              }
            },
            {
              selector: '.highlighted',
              style: {
                'background-color': '#e85e56',
                'transition-property': 'background-color',
                'transition-duration': '0.5s'
              }
            }
          ],

          layout: {
            name: "circle",
            avoidOverlap: true,
            nodeDimensionsIncludeLabels: true
          },

          panningEnabled: true, // Enable panning
          userPanningEnabled: true, // Allow users to pan the graph
          boxSelectionEnabled: false // Disable box selection

        });

        var file = event.target.files[0];
        var reader = new FileReader();

        reader.onload = function (e) {
          var contents = e.target.result;
          var lines;

          contents = addWeightsToEdges(contents);
          console.log(contents);
          lines = contents.split("\n");

          var nodesAndEdges = lines[0].split(" ");
          var numNodes = parseInt(nodesAndEdges[0]);
          var numEdges = parseInt(nodesAndEdges[1]);
          if(numNodes < 100) {
            cy.remove(cy.elements());

            for (let i = 0; i < numNodes; i++) {
              cy.add({data: {id: String(i)}});
            }

            for (var i = 1; i <= numEdges; i++) {
              const [source, target] = lines[i].split(' ').map(Number);
              cy.add({data: {id: `edge${i}`, source: String(source), target: String(target)}});
            }


            var rootNode = "0"; // Set the root node ID as "0"
            cy.getElementById(rootNode).addClass("root");

            cy.layout({
              name: "breadthfirst",
              roots: '#0',
              avoidOverlap: true,
              nodeDimensionsIncludeLabels: true
            }).run();

            var bfs = cy.elements().bfs('#0', function () {
            }, true);
            var i = 0;
            var highlightNextEle = function () {
              if (i < bfs.path.length) {
                bfs.path[i].addClass('highlighted');

                i++;
                setTimeout(highlightNextEle, 800);
              }
            };
            highlightNextEle();

            var path = [];

            bfs.path.each(function(element){
              if (element.isNode()) {
                path.push(element.id());
              }
            });

            var messageElement = document.createElement('div');
            messageElement.innerText = 'Path: ' + path.join(' > ');
            messageElement.style.position = 'absolute';
            messageElement.style.top = '10px';
            messageElement.style.left = '10px';
            messageElement.style.fontSize = '16px';
            messageElement.style.fontFamily = 'Arial, sans-serif';
            messageElement.style.color = '#494949';

            var cyContainer = document.getElementById('cy');
            cyContainer.style.position = 'relative';
            cyContainer.appendChild(messageElement);

          }
        };

        reader.readAsText(file);

      }
      else if(chosenAlg === "Dijkstra") {

        var file = event.target.files[0];
        var reader = new FileReader();

        reader.onload = function (e) {
          var contents = e.target.result;
          var lines;


          lines = contents.split("\n");

          var nodesAndEdges = lines[0].split(" ");
          var numNodes = parseInt(nodesAndEdges[0]);
          var numEdges = parseInt(nodesAndEdges[1]);
          if(numNodes < 100) {
            const elements = [];

            // Add nodes to the graph
            for (let i = 0; i < numNodes; i++) {
              elements.push({data: {id: i.toString()}});
            }

            // Add edges with weights to the graph
            for (let i = 1; i <= numEdges; i++) {
              const [source, target, weight] = lines[i].split(' ');
              elements.push({data: {id: `edge${i}`, source, target, weight}});
            }


            var cy = cytoscape({
              container: document.getElementById("cy"),
              elements,
              style: [
                {
                  selector: 'node',
                  style: {
                    "background-color": "blue",
                    label: "data(id)",
                    "border-width": 2,
                    "border-color": "black",
                    width: 15,
                    height: 15
                  }
                },
                {
                  selector: 'edge[visited]',
                  style: {
                    'line-color': 'red'
                  }
                },
                {
                  selector: 'node[id = "0"]',
                  style: {
                    'background-color': 'red',
                    label: 'data(id)',
                    'border-width': 2,
                    'border-color': 'black',
                    width: 20,
                    height: 20
                  }
                },
                {
                  selector: 'edge',
                  style: {
                    width: 3,
                    'line-color': 'gray',
                    label: "data(weight)"
                  }
                },
                {
                  selector: '.highlighted',
                  style: {
                    'background-color': '#e85e56',
                    'transition-property': 'background-color',
                    'transition-duration': '0.5s'
                  }
                }
              ],

              layout: {
                name: "circle",
                avoidOverlap: true,
                nodeDimensionsIncludeLabels: true
              },

              panningEnabled: true, // Enable panning
              userPanningEnabled: true, // Allow users to pan the graph
              boxSelectionEnabled: false // Disable box selection

            });

            var rootNode = "0"; // Set the root node ID as "0"
            cy.getElementById(rootNode).addClass("root");

            cy.layout({
              name: "circle",
              roots: '#0',
              avoidOverlap: true,
              nodeDimensionsIncludeLabels: true
            }).run();

            function dijkstraAlgorithm(graph, sourceNodeId) {
              // Initialize data structures for distances and paths
              const distances = {};
              const paths = {};

              // Set initial distances to infinity and paths to empty arrays
              graph.nodes().forEach(node => {
                const nodeId = node.id();
                distances[nodeId] = Infinity;
                paths[nodeId] = [];
              });

              // Set distance of source node to 0
              distances[sourceNodeId] = 0;

              // Create a priority queue to store nodes based on their distances
              const priorityQueue = new PriorityQueue();
              priorityQueue.enqueue(sourceNodeId, 0);

              while (!priorityQueue.isEmpty()) {
                const {element: currentNodeId, priority: currentDistance} = priorityQueue.dequeue();

                // Visit each outgoing edge of the current node
                graph.edges('[source="' + currentNodeId + '"]').forEach(edge => {
                  const targetNodeId = edge.target().id();
                  const edgeWeight = parseInt(edge.data('weight'));

                  // Calculate the new distance
                  const newDistance = currentDistance + edgeWeight;

                  if (newDistance < distances[targetNodeId]) {
                    // Update the distance and path
                    distances[targetNodeId] = newDistance;
                    paths[targetNodeId] = [...paths[currentNodeId], currentNodeId];

                    // Enqueue the target node with the new distance
                    priorityQueue.enqueue(targetNodeId, newDistance);
                  }
                });
              }

              return {distances, paths};
            }

            const sourceNodeId = '0'; // Specify the source node ID
            const {distances, paths} = dijkstraAlgorithm(cy, sourceNodeId);
            var targetNodeIndex = Math.floor(Math.random() * (numNodes-1)) + 1;
            var targetNodeId = targetNodeIndex.toString();

            // Retrieve the shortest path from source to target
            const shortestPath = paths[targetNodeId];

            // Highlight the nodes in the shortest path
            shortestPath.forEach((nodeId, index) => {
              setTimeout(() => {
                cy.getElementById(nodeId).addClass('highlighted');
              }, index * 500); // Delay in milliseconds (0.5 seconds per node)
            });

            // Highlight the target node with a delay
            setTimeout(() => {
              cy.getElementById(targetNodeId).addClass('highlighted');
            }, shortestPath.length * 1000);

            // var messageElement = document.createElement('div');
            // messageElement.id = 'message';
            // messageElement.textContent = 'Exemplu: Algoritmul Dijkstra de la nodul 0 la nodul ' + targetNodeId;
            // messageElement.style.color = '#e85e56';
            // document.getElementById('traversal').appendChild(messageElement);


            var messageElement = document.createElement('div');
            messageElement.innerText = 'Shortest path from Node ' + sourceNodeId + ' to Node ' + targetNodeId +
              ' is : ' + shortestPath.join(' > ') + ' > ' + targetNodeId;
            messageElement.style.position = 'absolute';
            messageElement.style.top = '10px';
            messageElement.style.left = '10px';
            messageElement.style.fontSize = '16px';
            messageElement.style.fontFamily = 'Arial, sans-serif';
            messageElement.style.color = '#494949';

            var cyContainer = document.getElementById('cy');
            cyContainer.style.position = 'relative';
            cyContainer.appendChild(messageElement);

          }
        };

        reader.readAsText(file);

      }
      else if (chosenAlg === "Bellman Ford") {
        var file = event.target.files[0];
        var reader = new FileReader();

        reader.onload = function (e) {
          var contents = e.target.result;
          const lines = contents.trim().split('\n');

          const matrix = lines.slice(1).map(line => line.split(' ').map(Number));

          const numNodes = matrix.length;
          if(numNodes < 100) {
            const elements = [];
            // Add nodes to the graph
            for (let i = 0; i < numNodes; i++) {
              elements.push({data: {id: i.toString()}});
            }

            // Add edges with weights to the graph
            for (let i = 0; i < numNodes; i++) {
              for (let j = 0; j < numNodes; j++) {
                if (i !== j && matrix[i][j] !== 0) {
                  elements.push({
                    data: {
                      id: `edge_${i}_${j}`,
                      source: i.toString(),
                      target: j.toString(),
                      weight: matrix[i][j].toString()
                    },
                    classes: `edge_${i}_${j}`
                  });
                }
              }
            }

            var cy = cytoscape({
              container: document.getElementById("cy"),
              elements,
              style: [
                {
                  selector: 'node',
                  style: {
                    "background-color": "blue",
                    label: "data(id)",
                    "border-width": 2,
                    "border-color": "black",
                    width: 15,
                    height: 15
                  }
                },
                {
                  selector: 'edge[visited]',
                  style: {
                    'line-color': 'red'
                  }
                },
                {
                  selector: 'node[id = "0"]',
                  style: {
                    'background-color': 'red',
                    label: 'data(id)',
                    'border-width': 2,
                    'border-color': 'black',
                    width: 20,
                    height: 20
                  }
                },
                {
                  selector: 'edge',
                  style: {
                    width: 3,
                    'line-color': 'gray',
                    label: "data(weight)",
                    'target-arrow-color': 'blue',
                    'target-arrow-shape': 'triangle',
                    'curve-style': 'bezier'
                  }
                },
                {
                  selector: '.highlighted',
                  style: {
                    'background-color': '#e85e56',
                    'transition-property': 'background-color',
                    'transition-duration': '0.5s'
                  }
                }
              ],

              layout: {
                name: "circle",
                avoidOverlap: true,
                nodeDimensionsIncludeLabels: true
              },

              panningEnabled: true, // Enable panning
              userPanningEnabled: true, // Allow users to pan the graph
              boxSelectionEnabled: false // Disable box selection

            });

            var rootNode = "0"; // Set the root node ID as "0"
            cy.getElementById(rootNode).addClass("root");

            cy.layout({
              name: "circle",
              roots: '#0',
              avoidOverlap: true,
              nodeDimensionsIncludeLabels: true
            }).run();

            function bellmanFord(cy, startNode) {
              var nodes = cy.nodes();
              var edges = cy.edges();
              var distance = {};
              var predecessor = {};

              // Step 1: Initialization
              nodes.forEach(function (node) {
                distance[node.id()] = Infinity;
                predecessor[node.id()] = null;
              });
              distance[startNode] = 0;

              // Step 2: Relax edges repeatedly
              for (var i = 1; i < nodes.length; i++) {
                edges.forEach(function (edge) {
                  var source = edge.source().id();
                  var target = edge.target().id();
                  var weight = edge.data('weight');
                  if (distance[source] !== Infinity && distance[source] + weight < distance[target]) {
                    distance[target] = distance[source] + weight;
                    predecessor[target] = source;
                  }
                });
              }

              // Step 3: Check for negative-weight cycles
              edges.forEach(function (edge) {
                var source = edge.source().id();
                var target = edge.target().id();
                var weight = edge.data('weight');
                if (distance[source] !== Infinity && distance[source] + weight < distance[target]) {
                  console.log('Graph contains negative-weight cycle');
                  return;
                }
              });

              return {distance, predecessor};
            }

            var startNode = '0'; // Replace '0' with your desired starting node
            var targetNode = cy.nodes()[Math.floor(Math.random() * (cy.nodes().length-1))+1].id(); // Choose a random target node
            var result = bellmanFord(cy, startNode);


            var path = [];
            var node = targetNode;
            while (node !== null) {
              path.unshift(node);
              node = result.predecessor[node];
            }

            cy.batch(function () {
              cy.elements().not('.highlighted').addClass('faded'); // Fade all elements except highlighted ones
              cy.elements().removeClass('highlighted');

              path.forEach(function (nodeId, index) {
                setTimeout(function () {
                  cy.$('#' + nodeId).removeClass('faded').addClass('highlighted');
                  if (index > 0) {
                    cy.$('#' + path[index - 1] + '-' + nodeId).addClass('highlighted');
                  }
                }, index * 1000);
              });
            });

            // var messageElement = document.createElement('div');
            // messageElement.id = 'message';
            // messageElement.textContent = 'Exemplu: Algoritmul Bellman Ford de la nodul 0 la nodul ' + targetNode;
            // messageElement.style.color = '#e85e56';
            // document.getElementById('traversal').appendChild(messageElement);

            var messageElement = document.createElement('div');
            messageElement.innerText = 'Shortest path from Node ' + startNode + ' to Node ' + targetNode +
              ' is : ' + path.join(' > ');
            messageElement.style.position = 'absolute';
            messageElement.style.top = '10px';
            messageElement.style.left = '10px';
            messageElement.style.fontSize = '16px';
            messageElement.style.fontFamily = 'Arial, sans-serif';
            messageElement.style.color = '#494949';

            var cyContainer = document.getElementById('cy');
            cyContainer.style.position = 'relative';
            cyContainer.appendChild(messageElement);
          }
        };

        reader.readAsText(file);
      }

    });

});

document.addEventListener('DOMContentLoaded', function() {
  var instructionsBtn = document.getElementById('instructions-btn');
  var instructionsModal = document.getElementById('instructions-modal');
  var pages = document.getElementsByClassName('page');
  var currentPageIndex = 0;
  var closeBtn = document.getElementById('close-btn');
  var nextBtn = document.getElementById('next-btn');
  var prevBtn = document.getElementById('prev-btn');

  function showPage(pageIndex) {
    for (var i = 0; i < pages.length; i++) {
      pages[i].style.display = 'none';
    }
    pages[pageIndex].style.display = 'block';
    currentPageIndex = pageIndex;
  }
  function nextPage() {
    if (currentPageIndex < pages.length - 1) {
      showPage(currentPageIndex + 1);
    }
  }
  function prevPage() {
    if (currentPageIndex > 0) {
      showPage(currentPageIndex - 1);
    }
  }
  instructionsBtn.addEventListener('click', function() {
    showPage(0);
    instructionsModal.style.display = 'block';
  });
  nextBtn.addEventListener('click', nextPage);
  prevBtn.addEventListener('click', prevPage);
  closeBtn.addEventListener('click', function() {
    instructionsModal.style.display = 'none';
  });
});
