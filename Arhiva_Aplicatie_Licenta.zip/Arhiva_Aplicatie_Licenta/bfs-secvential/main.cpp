#include <vector>
#include <queue>
#include <iostream>
#include <functional>
#include <string>
#include <fstream>
#include <chrono>

using namespace std;

vector<vector<int>>graph;
queue <int> qq;
int *marked = NULL;
int nodesNum, node1, node2;

void s_init(string filename)
{
    ifstream fin(filename);

    fin >> nodesNum;

    graph.resize(nodesNum + 1);
    marked = new int[nodesNum + 1]();

    while (fin >> node1 >> node2)
    {
        graph[node1].push_back(node2);
        graph[node2].push_back(node1);
    }

    fin.close();
}


//Display the graph
void display () {
    for (unsigned int i = 0; i < graph.size(); ++i) {
        if (graph[i].size() != 0) {
            cout<< i<<"->";
            for (unsigned int j = 0; j < graph[i].size(); ++j) {
                cout<< graph[i][j]<<" ";
            }
            cout<<"\n";
        }
    }
}

//Serial implimentation of BFS
void s_bfs (int startNode) {

    qq.push (startNode);

    while (! qq.empty()) {
        int node = qq.front();
        qq.pop();

        marked[node] = 2;

        for (unsigned int i = 0; i < graph[node].size(); ++i) {
            if ( marked[graph[node][i]] == 0 ) {
                qq.push (graph[node][i]);
                marked[graph[node][i]] = 1;
            }
        }
    }
}

int main(int argc, char const *argv[])
{
    if (argc <= 1) {
        cout<<"INPUT FILE WAS NOT FOUND!";
    }
    string filename = argv[1];
    //initialize the graph for serial
    s_init(filename);

    /* Perform Serial Breadth First Search */
    auto start = chrono::steady_clock::now();
    s_bfs(0);
    auto end = chrono::steady_clock::now();
    auto dur = chrono::duration_cast<chrono::microseconds>(end - start).count();
    cout<< "\nSerial BFS: "<<dur<<"ms\n\n";
    graph.clear();


    return 0;
}